let Sab1 = document.querySelector("#Sab1");
let Sab2 = document.querySelector("#Sab2");
let Sab3 = document.querySelector("#Sab3");
let Sab4 = document.querySelector("#Sab4");
let Refri = document.querySelector("#Refri");
let botao = document.querySelector("#botao");
let resume = document.querySelector("#resume");
let preco = document. querySelector("#preco")


function elabora(){

    let sabor1 = Sab1.value
    let sabor2 = Sab2.value
    let sabor3 = Sab3.value
    let sabor4 = Sab4.value
    let refrigerante = Number(Refri.value)


    let elabor = ("Pizza de " + sabor1 + ", " + sabor2 + ", " + sabor3 + " e " + sabor4 + " acompanhado de " + refrigerante + " refrigerantes")

    resume.textContent = elabor

    let precoF = "Total:" + ((48) + 7 * refrigerante) + "R$"

    preco.textContent = precoF
}

botao.onclick = function(){

    elabora()
}