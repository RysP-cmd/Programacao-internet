let Val1 = document.querySelector("#Val1");
let Val2 = document.querySelector("#Val2");
let Val3 = document.querySelector("#Val3");
let botao = document.querySelector("#botao");
let mediaA = document.querySelector("#mediaA");
let mediaP = document.querySelector("#mediaP");
let Smedia = document.querySelector("#Smedia");
let Mmedias = document.querySelector("#Mmedias");

function mediareajuste(){

   let num1 = Number(Val1.value);
   let num2 = Number(Val2.value);
   let num3 = Number(Val3.value);

   let mediaAritmetica = (num1 + num2 + num3) / 3;

   let mediaPonderada = (( num1 * 3) + (num2 * 2) +(num3 * 5)) / 10;



   let Somamedias = mediaAritmetica + mediaPonderada;


   let mediaDasMedias = Somamedias /2;


   mediaA.textContent = mediaAritmetica;
   mediaP.textContent = mediaPonderada;
   Smedia.textContent = Somamedias;
   Mmedias.textContent = mediaDasMedias;

   
}

botao.onclick = function(){

   mediareajuste();
}
