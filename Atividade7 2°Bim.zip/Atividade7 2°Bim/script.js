let Num1 = document.querySelector("#Num1")
let botao = document.querySelector("#botao")
let result = document.querySelector("#result")

function decision(){

    let numero1 = Number(Num1.value)

    if(numero1 % 2 === 0){

        result.textContent = "Par"
    }else{

        result.textContent = "Impar"
    }
}

botao.onclick = function(){

    decision()
}