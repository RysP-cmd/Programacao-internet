let Value1 = document.querySelector("#Value1");
let botao = document.querySelector("#botao");
let Rea1 = document.querySelector("#Rea1")
let Rea2 = document.querySelector("#Rea2")
let Rea5 = document.querySelector("#Rea5")
let Rea10 = document.querySelector("#Rea10")


function reajuste(){

    let valor = Number(Value1.value);

    let reajuste1 = (valor * 0.01);

    let reajuste2 = (valor * 0.02);

    let reajuste5 = (valor * 0.05);

    let reajuste10 = (valor * 0.10);


Rea1.textContent = "Reajuste em 1% :" + reajuste1 + valor
Rea2.textContent = "Reajuste em 2% :" + reajuste2 + valor
Rea5.textContent = "Reajuste em 5% :" + reajuste5 + valor
Rea10.textContent = "Reajuste em 5% :"reajuste10 + valor

}

botao.onclick = function(){

    reajuste()
}