let Val1 = document.querySelector("#Val1");
let Val2 = document.querySelector("#Val2");
let adicao = document.querySelector("#adicao");
let subtrac = document.querySelector("#subtrac");
let multipli = document.querySelector("#multipli");
let divisao = document.querySelector("#divisao");
let botao = document.querySelector("#botao")

function operacao(){

    let valor1 = Number(Val1.value);
    let valor2 = Number(Val2.value);

    let adi = (valor1 + valor2);
    let sub = (valor1 - valor2);
    let mult = (valor1 * valor2);
    let div = (valor1 / valor2);


    adicao.textContent = adi;
    subtrac.textContent = sub;
    multipli.textContent = mult;
    divisao.textContent = div;

}

botao.onclick = function(){

    operacao()
}

