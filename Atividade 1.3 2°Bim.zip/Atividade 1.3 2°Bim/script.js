let base = document.querySelector("#base");
let altura = document.querySelector("#altura");
let result = document.querySelector("#result");
let botao = document.querySelector("#botao")

function  dimension(){

    let baseV = Number(base.value)
    let alturaV = Number(altura.value)

    result.textContent = (baseV * alturaV) + "Mts^2"
}

botao.onclick = function(){

    dimension()
}