let pessoasV = document.querySelector("#pessoasV");
let ValQ = document.querySelector("#ValQ");
let ValO = document.querySelector("#ValO");
let botao = document.querySelector("#botao");


function deducao(){

    let pessoas = Number(pessoasV.value);

    let queijo = (50 * pessoas);

    let ovos = (2 * pessoas);


    ValQ.textContent = queijo
    ValO.textContent = ovos
}

botao.onclick = function (){

    deducao()
}