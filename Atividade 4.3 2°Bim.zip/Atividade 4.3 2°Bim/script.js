let anosV = document.querySelector("#anosV")
let result = document.querySelector("#result")
let botao = document.querySelector("#botao")

function decompose(){

    result.textContent = Number(anosV.value * 365)
}
botao.onclick = function(){

    decompose()
}