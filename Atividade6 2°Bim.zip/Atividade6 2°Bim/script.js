let Val1 = document.querySelector("#Val1");
let Val2 = document.querySelector("#Val2");
let Val3 = document.querySelector("#Val3");
let Val4 = document.querySelector("#Val4");
let botao = document.querySelector("#botao");
let Result = document.querySelector("#Result");

botao.onclick = function () {
    let valor1 = Number(Val1.value);
    let valor2 = Number(Val2.value);
    let valor3 = Number(Val3.value);
    let valor4 = Number(Val4.value);

    let menor = valor1; // Supondo que o primeiro seja o menor

    if (valor2 < menor) {
        menor = valor2;
    }

    if (valor3 < menor) {
        menor = valor3;
    }

    if (valor4 < menor) {
        menor = valor4;
    }

    Result.textContent = "O menor valor e: " + menor;
}