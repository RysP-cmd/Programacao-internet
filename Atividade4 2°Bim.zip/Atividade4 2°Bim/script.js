let Val1 = document.querySelector("#Val1");
let Val2 = document.querySelector("#Val2");
let Val3 = document.querySelector("#Val3");
let Botao = document.querySelector("#Botao");
let mediaA = document.querySelector("#mediaA");
let mediaP = document.querySelector("#mediaP");
let Smedia = document.querySelector("#Smedia");
let Mmedias = document.querySelector("#Mmedias")

function mediareajuste(){

     let mediaA = number(Val1.value + Val2.value + Val3.value) / 3;
}

function mediaponder(){

   let mediaP = number( Val1 * 3 + Val2 * 2 + Val3 * 5) / 10;
}

function somamedias(){

   let Smedia = Number();
}

function mediamedias(){

    let Mmedias = Number( )
}