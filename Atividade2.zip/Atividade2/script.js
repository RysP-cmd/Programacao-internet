let ValKg = document.querySelector("#ValKg");
let KgQuant = document.querySelector("#KgQuant");
let Execucao = document.querySelector("#Execucao");
let Resultado = document.querySelector("#Resultado");

function valores(){

    let Valor = (ValKg.value);
    let Kilos = (KgQuant.value);

    Resultado.textContent = (Valor * Kilos)
}

Execucao.onclick = function(){

    valores();
}