let GasV = document.querySelector("#GasV")
let dinheiroP = document.querySelector("#dinheiroP")
let result = document.querySelector("#result")
let botao = document.querySelector("#botao")

function abastecido(){

    result.textContent = Number(dinheiroP.value / GasV.value).toFixed(2) + "L";
}

botao.onclick = function(){

    abastecido()
}