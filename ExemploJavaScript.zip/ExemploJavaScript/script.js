let titulo = document.querySelector("#titulo");
let campoTexto = document.querySelector("#campoTexto")
let btTrocarTexto = document.querySelector("#btTrocarTexto")

function alterarTexto(){
    //retirando o valor retirado no input
    //e jogando na variavel
    let textodigitado = campoTexto.value;

    //atribuindo ao elemento titulo o texto que foi digitado
    //no input
    titulo.textContent = textodigitado;
}

//atribuindo uma ação de clicar no botão
btTrocarTexto.onclick = function(){
    alterarTexto();
}