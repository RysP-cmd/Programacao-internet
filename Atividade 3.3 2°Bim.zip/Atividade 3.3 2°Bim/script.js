let paes = document.querySelector("#paes")
let broas = document.querySelector("#broas")
let faturaM = document.querySelector("#faturaM")
let valorInv = document.querySelector("#valorInv")
let botao = document.querySelector("#botao")

function resume(){

    let paesV = Number(paes.value) * 0.12
    let broaV = Number(broas.value) * 1.50

    faturaM.textContent= (paesV + broaV) + "R$"

    valorInv.textContent= ((paesV + broaV) * 0.1) + "R$"

    
}

botao.onclick = function(){

    resume()
}