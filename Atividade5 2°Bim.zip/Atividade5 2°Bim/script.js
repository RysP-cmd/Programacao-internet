let Num1 = document.querySelector("#Num1");
let Num2 = document.querySelector("#Num2");
let Botao = document.querySelector("#Botao");
let result = document.querySelector("#result");

function decision(){

    let valor1 = Number(Num1.value);
    let valor2 = Number(Num2.value);

if(valor1 < valor2){

    result.textContent ="Resultado Maior" + (valor2);

}else{

    result.textContent = "Resultado Maior" + (valor1);
}}

Botao.onclick = function(){
 
    decision();
}
