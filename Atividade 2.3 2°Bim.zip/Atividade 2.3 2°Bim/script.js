let cavalos = document.querySelector("#cavalos")
let result = document.querySelector("#result")
let botao = document.querySelector("#botao")

function cabalos(){

    let caVV= Number(cavalos.value)

    result.textContent = (caVV * 4)
}

botao.onclick = function(){

    cabalos()
}